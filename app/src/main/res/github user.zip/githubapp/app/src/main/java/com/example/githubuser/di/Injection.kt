package com.example.githubuser.di

import android.content.Context
import com.example.githubuser.core.Repository
import com.example.githubuser.core.remote.retrofit.ApiConfig
import com.example.githubuser.core.remote.retrofit.ApiService

object Injection {
    fun provideRepository(context: Context): Repository{
        val apiService = ApiConfig.getApiService()
        return Repository.getInstance(apiService)
    }
}
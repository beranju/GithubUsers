package com.example.githubuser.ui.detail

import androidx.lifecycle.ViewModel
import com.example.githubuser.core.Repository

class DetailViewModel(private val repository: Repository) : ViewModel() {
    fun fetchDetailUser(login: String) = repository.fetchDetailUser(login)

    fun fetchFollow(login: String, follow: String) = repository.fetchFollow(login, follow)
}